$(function () {

    $('.toggleBtn').click(() => {
        $('.menu').toggle('active');
    })



})